import 'package:flutter/material.dart';
import 'login_screen.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      //Tela Inicial
      title: 'Splash Screen',
      theme: ThemeData(
          primarySwatch: Colors.deepPurple,
          visualDensity: VisualDensity.adaptivePlatformDensity
      ),
      home: SlashScreen(),
      routes: {
        '/login':(context)=> LoginScreen(),
      },
    );
  }
}
class SlashScreen extends StatefulWidget{
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SlashScreen>{
  @override
  void initState(){
    super.initState();
    Future.delayed(Duration(seconds: 2),(){
      Navigator.pushReplacementNamed(context, '/login');
    });
  }
  Widget build (BuildContext context){
    return Scaffold(
      appBar: AppBar(
          title: Text('Splash Screen')
      ),
      body: Container(
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/logo.png'),
                fit:BoxFit.cover
            )
        ),
        child: Center(
          child: CircularProgressIndicator(),
        ),
      ),
    );
  }
}


